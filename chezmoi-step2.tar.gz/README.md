# Step 2 bundle (chezmoi source layout)

## 1. Install tools
    sudo apt install ripgrep fd-find bat eza zoxide fzf git-delta tmux wl-clipboard keyd fonts-firacode
    apt policy starship lazygit        # if absent or ancient: mise use -g starship lazygit
    mkdir -p ~/.local/bin && ln -sf "$(command -v fdfind)" ~/.local/bin/fd && ln -sf "$(command -v batcat)" ~/.local/bin/bat
    fzf --version                      # needs >= 0.48 for `fzf --zsh`

## 2. Merge into the dotfiles repo (review before applying)
    tar xzf chezmoi-step2.tar.gz -C "$(chezmoi source-path)"     # then `git rm` the old dot_zshrc pieces you replaced
    chezmoi init                       # asks for the profile (personal/work)
    chezmoi diff                       # read it, then: chezmoi apply -v   (-v shows the plugin clones)
    sudo cp keyd.conf /etc/keyd/default.conf && sudo keyd reload   # /etc is outside chezmoi's reach (Step 7 automates this)

## 3. Git: delta + saner conflicts
    git config --global core.pager delta
    git config --global interactive.diffFilter 'delta --color-only'
    git config --global delta.navigate true
    git config --global merge.conflictStyle zdiff3

## 4. Checks
    ls ~/.local/share/zsh/plugins                                       # 3 directories expected
    for i in 1 2 3; do /usr/bin/time -f %es zsh -i -c exit; done      # target < 0.1s
    zsh -c 'cd <some uv/mise project> && which python'                # must resolve via mise shims
    type -a ls cp mv sudo                                              # which implementations 26.04 gave you

## 5. Persistent terminal: ddterm extension (default toggle F12), command `tmux new -As main`
